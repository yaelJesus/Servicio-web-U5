/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package paqServ;

import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.xml.ws.RequestWrapper;
import javax.xml.ws.ResponseWrapper;


@WebService(serviceName = "NewWebService")
public class NewWebService {


    /**
     * Web service operation
     */
    @WebMethod(operationName = "CompilacionDeNumeros_1")
    @RequestWrapper(className = "paqServ.CompilacionDeNumeros_1")
    @ResponseWrapper(className = "paqServ.CompilacionDeNumeros_1Response")
    public Integer CompilacionDeNumeros(@WebParam(name = "PrimeraCantidad") int PrimeraCantidad, @WebParam(name = "SegundaCantidad") int SegundaCantidad, @WebParam(name = "TerceraCantidad") int TerceraCantidad) {
        //TODO write your implementation code here:
        return null;
    }
}
